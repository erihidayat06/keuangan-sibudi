@extends('layouts.main')

@section('container')
    <h1 class="text-center">
        Selamat Datang Di Halaman Admin
    </h1>
@endsection
